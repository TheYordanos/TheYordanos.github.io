import html, re, subprocess
from pathlib import Path

def front_matter(text):
    m = re.match(r"---\n(.*?)\n---", text, re.S)
    lines = m.group(1).splitlines() if m else []
    return {k.strip(): v.strip().strip("\"'")
        for k, v in (line.split(":", 1) for line in lines if ":" in line)}

Path("articles").mkdir(exist_ok=True)
posts = []
for md in sorted(Path("articles_md").glob("*.md")):
    meta = front_matter(md.read_text(encoding="utf-8"))
    if meta.get("draft") == "true":
        continue
    subprocess.run(["pandoc", str(md), "--standalone", "--css", "../style.css",
        "--lua-filter", "sidenotes.lua", "-o", f"articles/{md.stem}.html"], check=True)
    posts.append((meta.get("date", ""), md.stem, meta.get("title", md.stem)))

posts.sort(reverse=True)
items = "\n".join(
    f'\t\t<li>{d} <a href="articles/{slug}.html">{html.escape(t)}</a></li>'
    for d, slug, t in posts)

index = Path("index.html")
page = index.read_text(encoding="utf-8")
page = re.sub(r"(<!-- ARTICLES:START -->).*(<!-- ARTICLES:END -->)",
    lambda m: f"{m[1]}\n{items}\n\t\t{m[2]}", page, flags=re.S)
index.write_text(page, encoding="utf-8")